import React from 'react';

interface WaveformProps {
  isPlaying: boolean;
}

const Waveform: React.FC<WaveformProps> = ({ isPlaying }) => {
  return (
    <div className="flex items-center justify-center gap-1 h-16 w-full max-w-xs mx-auto my-4 overflow-hidden">
      {[...Array(20)].map((_, i) => (
        <div
          key={i}
          className={`w-1 bg-gradient-to-t from-blue-500 to-cyan-300 rounded-full transition-all duration-100 ${
            isPlaying ? 'audio-wave-bar' : 'h-1'
          }`}
          style={{
            animationDuration: `${0.4 + Math.random() * 0.6}s`,
            animationDelay: `${Math.random() * 0.5}s`,
            height: isPlaying ? undefined : '4px' 
          }}
        ></div>
      ))}
    </div>
  );
};

export default Waveform;