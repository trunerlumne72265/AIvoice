import { GoogleGenAI, Modality } from "@google/genai";
import { decode, decodeAudioData } from "../utils/audioUtils";

// Initialize Gemini Client
// IMPORTANT: API_KEY must be provided via environment variable
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SCRIPT_MODEL = 'gemini-2.5-flash';
const TTS_MODEL = 'gemini-2.5-flash-preview-tts';

/**
 * Step 1: Convert raw text into a dialogue script.
 * We need to format it specifically so the TTS model understands who is speaking.
 */
export const generateConversationScript = async (originalText: string): Promise<string> => {
  const prompt = `
    Rewrite the following promotional text into a lively, natural conversation script in Japanese between two people, named "Kore" and "Puck".
    
    Rules:
    1. The conversation MUST be in Japanese.
    2. Keep the tone casual, friendly, and energetic (like colleagues chatting).
    3. Ensure all key product information from the original text is included.
    4. The output format MUST be strictly:
       Kore: [text]
       Puck: [text]
       ...
    5. Do not add stage directions like (laughing) or *gestures*. Just the spoken text.
    6. Keep it short and punchy.

    Original Text:
    "${originalText}"
  `;

  const response = await ai.models.generateContent({
    model: SCRIPT_MODEL,
    contents: prompt,
  });

  const text = response.text;
  if (!text) throw new Error("Failed to generate script.");
  return text.trim();
};

/**
 * Step 2: Convert the dialogue script into multi-speaker audio.
 */
export const generateMultiSpeakerAudio = async (script: string): Promise<AudioBuffer> => {
  // Construct the prompt for the TTS model
  const ttsPrompt = `TTS the following conversation:\n${script}`;

  const response = await ai.models.generateContent({
    model: TTS_MODEL,
    contents: [{ parts: [{ text: ttsPrompt }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        multiSpeakerVoiceConfig: {
          speakerVoiceConfigs: [
            {
              speaker: 'Kore',
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: 'Kore' } // Female-sounding, generally
              }
            },
            {
              speaker: 'Puck',
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: 'Puck' } // Male-sounding, generally
              }
            }
          ]
        }
      }
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  
  if (!base64Audio) {
    throw new Error("No audio data returned from Gemini.");
  }

  // Decode audio
  // Note: 24000Hz is a common sample rate for Gemini TTS, though it might vary.
  // We will assume 24kHz for high quality standard output.
  const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
  const audioBytes = decode(base64Audio);
  
  // Clean up context if we just created it for decoding, or keep it?
  // We return the buffer, so the App can play it with its own context or this one.
  // For simplicity, we decode using a temporary context or the main one.
  
  return await decodeAudioData(audioBytes, audioContext, 24000, 1);
};