import React, { useState, useRef, useEffect } from 'react';
import { generateConversationScript, generateMultiSpeakerAudio } from './services/geminiService';
import { bufferToWav } from './utils/audioUtils';
import { AppStatus } from './types';
import Waveform from './components/Waveform';

// Default text provided by the user
const DEFAULT_TEXT = `お疲れさまです！
寒い季節、お酒のおつまみに「ちょっと濃い味」がほしくなる時ってありますよね。
そんな時におすすめなのが、
ピリッと旨い「ピリ辛サラミ焼きチーズ」！
サラミと焼きチーズの濃厚ダブルパンチに、ピリ辛が加わって、お酒がぐっと進む味わいです。
寒い冬こそ、暖かいお部屋でビールと一緒にぜひどうぞ！
ほかにも定番の 「一口カルパス」
ちょっと珍しいタンのジャーキー 「おつまみ塩たん」 をご用意しております。
おつまみコーナーで好評発売中です！
是非ご覧ください！`;

const App: React.FC = () => {
  const [inputText, setInputText] = useState(DEFAULT_TEXT);
  const [generatedScript, setGeneratedScript] = useState<string>('');
  const [status, setStatus] = useState<AppStatus>(AppStatus.IDLE);
  const [audioBuffer, setAudioBuffer] = useState<AudioBuffer | null>(null);
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  
  // Audio playback refs
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  // Initialize AudioContext on first interaction
  useEffect(() => {
    // We defer creation until needed or user interaction to comply with browser policies
    return () => {
      if (audioContext && audioContext.state !== 'closed') {
        audioContext.close();
      }
    };
  }, [audioContext]);

  const handleGenerate = async () => {
    try {
      if (!process.env.API_KEY) {
        throw new Error("API Key is missing. Please set process.env.API_KEY.");
      }

      setErrorMsg(null);
      setAudioBuffer(null);
      setIsPlaying(false);
      
      // Step 1: Generate Script
      setStatus(AppStatus.GENERATING_SCRIPT);
      const script = await generateConversationScript(inputText);
      setGeneratedScript(script);

      // Step 2: Generate Audio
      setStatus(AppStatus.GENERATING_AUDIO);
      const buffer = await generateMultiSpeakerAudio(script);
      setAudioBuffer(buffer);
      
      // Setup Audio Context if not ready
      if (!audioContext) {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        setAudioContext(ctx);
      }

      setStatus(AppStatus.SUCCESS);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "An unexpected error occurred.");
      setStatus(AppStatus.ERROR);
    }
  };

  const playAudio = async () => {
    if (!audioBuffer) return;
    
    let ctx = audioContext;
    if (!ctx) {
      ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      setAudioContext(ctx);
    }

    if (ctx && ctx.state === 'suspended') {
      await ctx.resume();
    }

    // Stop previous if playing
    if (audioSourceRef.current) {
      audioSourceRef.current.stop();
    }

    const source = ctx!.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(ctx!.destination);
    
    source.onended = () => {
      setIsPlaying(false);
      setStatus(AppStatus.SUCCESS);
    };

    audioSourceRef.current = source;
    source.start();
    setIsPlaying(true);
    setStatus(AppStatus.PLAYING);
  };

  const stopAudio = () => {
    if (audioSourceRef.current) {
      audioSourceRef.current.stop();
      setIsPlaying(false);
      setStatus(AppStatus.SUCCESS);
    }
  };

  const handleDownload = () => {
    if (!audioBuffer) return;
    const wavBlob = bufferToWav(audioBuffer);
    const url = URL.createObjectURL(wavBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'gemini_conversation.wav';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100 font-sans selection:bg-blue-500 selection:text-white pb-20">
      {/* Header */}
      <header className="border-b border-gray-800 bg-gray-900/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center font-bold text-sm">
              G
            </div>
            <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400">
              Gemini TTS Studio
            </h1>
          </div>
          <div className="text-xs text-gray-500 border border-gray-800 rounded-full px-3 py-1">
            v2.5 Flash Tech Preview
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-10 space-y-12">
        
        {/* Intro */}
        <section className="text-center space-y-4">
          <h2 className="text-4xl md:text-5xl font-extrabold tracking-tight">
            Turn text into <span className="text-blue-400">conversations</span>.
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Transform your promotional copy or announcements into a dynamic, multi-speaker dialogue using the power of Gemini AI.
          </p>
        </section>

        {/* Input Section */}
        <section className="bg-gray-900 border border-gray-800 rounded-2xl p-1 shadow-2xl shadow-blue-900/10">
          <div className="bg-gray-950 rounded-xl p-6">
            <label htmlFor="input-text" className="block text-sm font-medium text-gray-400 mb-2 uppercase tracking-wider">
              Source Text (Japanese)
            </label>
            <textarea
              id="input-text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="w-full h-48 bg-gray-900 text-gray-200 p-4 rounded-lg border border-gray-800 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all resize-none font-mono text-sm leading-relaxed"
              placeholder="Enter your text here..."
            />
            
            <div className="mt-4 flex justify-end">
              <button
                onClick={handleGenerate}
                disabled={status === AppStatus.GENERATING_SCRIPT || status === AppStatus.GENERATING_AUDIO}
                className={`
                  relative px-8 py-3 rounded-lg font-bold text-white transition-all transform active:scale-95
                  ${(status === AppStatus.GENERATING_SCRIPT || status === AppStatus.GENERATING_AUDIO)
                    ? 'bg-gray-700 cursor-not-allowed opacity-75' 
                    : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 shadow-lg shadow-blue-500/25'}
                `}
              >
                {status === AppStatus.GENERATING_SCRIPT && (
                  <span className="flex items-center gap-2">
                    <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Drafting Script...
                  </span>
                )}
                {status === AppStatus.GENERATING_AUDIO && (
                  <span className="flex items-center gap-2">
                     <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Synthesizing Voices...
                  </span>
                )}
                {status !== AppStatus.GENERATING_SCRIPT && status !== AppStatus.GENERATING_AUDIO && (
                  <span>Generate Audio</span>
                )}
              </button>
            </div>
          </div>
        </section>

        {/* Error Display */}
        {errorMsg && (
          <div className="bg-red-900/20 border border-red-500/50 text-red-200 p-4 rounded-xl flex items-start gap-3">
             <svg className="w-5 h-5 text-red-500 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
             <div>
               <h3 className="font-bold">Generation Failed</h3>
               <p className="text-sm opacity-80">{errorMsg}</p>
             </div>
          </div>
        )}

        {/* Results Section */}
        {(generatedScript || status === AppStatus.SUCCESS || status === AppStatus.PLAYING) && (
          <div className="grid md:grid-cols-2 gap-8 animate-fade-in-up">
            
            {/* Script Column */}
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-gray-200 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-500"></span>
                Generated Dialogue
              </h3>
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 h-96 overflow-y-auto custom-scrollbar">
                {generatedScript.split('\n').map((line, idx) => {
                  const isKore = line.trim().startsWith('Kore:');
                  const isPuck = line.trim().startsWith('Puck:');
                  
                  return (
                    <div key={idx} className={`mb-4 flex ${isPuck ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                        isKore 
                          ? 'bg-gray-800 text-gray-200 rounded-tl-none' 
                          : isPuck 
                            ? 'bg-blue-900/40 text-blue-100 rounded-tr-none border border-blue-800/50'
                            : 'bg-gray-800 text-gray-400 italic'
                      }`}>
                        <div className="text-[10px] font-bold uppercase tracking-wider opacity-50 mb-1">
                          {isKore ? 'Kore' : isPuck ? 'Puck' : 'Script'}
                        </div>
                        {line.replace(/^(Kore:|Puck:)/, '').trim()}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Audio Column */}
            <div className="flex flex-col h-full space-y-4">
              <h3 className="text-lg font-bold text-gray-200 flex items-center gap-2">
                 <span className={`w-2 h-2 rounded-full ${audioBuffer ? 'bg-green-500' : 'bg-gray-600'}`}></span>
                 Audio Output
              </h3>
              
              <div className="flex-1 bg-gray-900 border border-gray-800 rounded-xl p-8 flex flex-col items-center justify-center relative overflow-hidden group">
                {/* Background Glow */}
                <div className={`absolute inset-0 bg-blue-500/10 blur-3xl transition-opacity duration-1000 ${isPlaying ? 'opacity-100' : 'opacity-20'}`}></div>

                {audioBuffer ? (
                  <div className="relative z-10 w-full flex flex-col items-center">
                    <Waveform isPlaying={isPlaying} />
                    
                    <div className="text-center mb-8">
                       <p className="text-2xl font-bold text-white mb-1">Preview Ready</p>
                       <p className="text-gray-400 text-sm">Duration: {audioBuffer.duration.toFixed(1)}s</p>
                    </div>

                    <div className="flex gap-4">
                      {!isPlaying ? (
                        <button 
                          onClick={playAudio}
                          className="w-16 h-16 rounded-full bg-white text-gray-900 flex items-center justify-center hover:bg-gray-200 transition-colors shadow-lg shadow-white/20"
                          title="Play Audio"
                        >
                          <svg className="w-8 h-8 ml-1" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                        </button>
                      ) : (
                        <button 
                          onClick={stopAudio}
                          className="w-16 h-16 rounded-full bg-red-500 text-white flex items-center justify-center hover:bg-red-600 transition-colors shadow-lg shadow-red-500/30"
                          title="Stop Audio"
                        >
                           <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"><path d="M6 6h12v12H6z"/></svg>
                        </button>
                      )}
                      
                      <button 
                        onClick={handleDownload}
                        className="w-16 h-16 rounded-full bg-gray-700 text-white flex items-center justify-center hover:bg-gray-600 transition-colors border border-gray-600 shadow-lg"
                        title="Download WAV"
                      >
                         <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center text-gray-600 relative z-10">
                    <div className="w-16 h-16 rounded-full bg-gray-800 mx-auto mb-4 flex items-center justify-center border border-gray-700">
                       <svg className="w-8 h-8 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"></path></svg>
                    </div>
                    <p>Audio will appear here</p>
                  </div>
                )}
              </div>
            </div>

          </div>
        )}
      </main>
    </div>
  );
};

export default App;