export enum AppStatus {
  IDLE = 'IDLE',
  GENERATING_SCRIPT = 'GENERATING_SCRIPT',
  GENERATING_AUDIO = 'GENERATING_AUDIO',
  PLAYING = 'PLAYING',
  ERROR = 'ERROR',
  SUCCESS = 'SUCCESS'
}

export interface GeneratedScript {
  rawText: string;
  formattedScript: string;
}

export interface AudioState {
  buffer: AudioBuffer | null;
  context: AudioContext | null;
  source: AudioBufferSourceNode | null;
}
